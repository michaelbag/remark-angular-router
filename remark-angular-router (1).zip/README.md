# remark-angular-router

[Edit on StackBlitz ⚡️](https://stackblitz.com/edit/remark-angular-router)